DEBUGGING

debugging-example.html
power.js
- These are the files I used to demonstrate how the browser
  debuggers work.  They aren't particularly interesting outside
  of the context of the demonstration.

console-example.html
- Shows use of the Console object to output to the web browsers'
  Console panel.

ASSIGNING EVENT HANDLERS

assignment-recommended-W3C.html
- Using the W3C's AddEventListener is the best approach.  While the
  third parameter is now optional, MDN still recommends providing it 
  for the broadest compatibility.

Traditional Approaches
You will see these approaches used in older code.

assignment-traditional-direct.html
- We originally used attribute values on the HTML element itself
  to assign event handlers.  This still works, but AddEventListener
  gives more flexiblity.

assignment-traditional-property.html
- Another traditional approach you may see is assigning to an on"event"
  property such as onclick on the DOM object we are interested in.
  This was useful as Internet Explorer did not support AddEventListener

Internet Explorer method
Don't use this, but this is how Microsoft wanted event listeners assigned.

assignment-IE.html
- This was the method used to assign event handlers in Internet Explorer
  rather than AddEventListener.  Both the traditional approaches above will
  also work in older Internet Explorer.  But use AddEventListener.

BASIC EVENT HANDLING
These examples show different events which can be assigned handlers

onclick-general.html
- We can add onclick listeners to any element that is rendered (i.e., that
  is actually displayed on the webpage).
- Here I demonstrate a traditional approach where I define a function and then
  assign that function using AddEventListener.
- I also show assigning an anonymous function literal using AddEventListener.
- Finally I show using an arrow function with AddEventListener.

body-test.html
body-test.js
- Note that if the actual webpage contents don't fill the full window,
  the body also doesn't fill the full window.
- If you want to be able to respond to a click anywhere, you're better off
  assigning a handler to the document object itself.

checkboxes-pizza.html
- Assigns event handlers to checkboxes using querySelectorAll.  Uses fact 
  that we have 7 ingredient to update cost of Piazza.

checkboxes-pizza-query.html
- Similar, but in this case, we only look at checkboxes with class="ingredient"
  this makes it easier to add more ingredients (since we don't have the 
  "magic number" 7 hardcoded into our code)

dealer.html
- OnMouseOver and OnMouseOut events can give you effects similar to the
  CSS :hover we saw previously.  In this case though we can execute any
  JavaScript we want in response to the Mouse going over an element.
- While quite popular for a time, this probably doesn't work well with
  mobile friendly websites, since mobile devices typically don't register
  someone "hovering" their finger above the screen.

onload.html
- We can trigger an action when a webpage has completed loading or when
  it unloads.

check-form.html
- We can execute JavaScript when someone tries to submit a form.
- We can also cancel using event.preventDefault (more on how this 
  works later)

select-color.html
select-color-e.html
- We've previously seen the select-color.html example where we
  change colors on a button click.
- We can do the same thing when a select is changed.  The correct
  property for this is onchanged it is _not_ onclick.  onclick works
  on some, but not all web browsers.

text-color-e.html
- We can also add an onchange listener to text fields.  

basic-keypress.html
basic-keypress.js
- We can add a keypress event to the document itself.

adv-keypress.html
adv-keypress.js
- We can also add a keypress to individual elements.

ADVANCED EVENTS
Event handlers will receive a single parameter which is 
an Event object.  We can access information on that Event
object to find information about the Event.

keypress.html
- We can get information about which key was pressed
- We can also determine if the SHIFT key, CTRL key, or AddEventListener
  key was also held down when the key was pressed.

mouse.html
- We can determine where a mouse was clicked.
- click only works on left-mouse in some web browsers

mouse-down.html
- Here we use mousedown instead of clicked.
- This gives us better support for non-left button clicking.

mouse-down-no-context.html
- We can also trigger an event when the context menu appears.
- Calling the preventDefault on the event object will prevent the
  context menu from showing up.
- In this case I'm only targetting clicks inside the text area, some
  right-mousing in the text area, there's no context menu.  Right-mousing
  outside of the text area and you'll see a context menu.

targets.html
- We have three properties on the event object which get information
  about objects related to the event.
- target is the object which actually triggered the event.
- relatedTarget's meaning various depending on the event.  In this
  case it's the element we are leaving.
- currentTarget is the object the event handler is actually on.
  as we'll see momentarily this isn't always the same as the target.

multiple-handlers.html
- We can assign multiple handlers to execute on the same event on the
  same object.

multiple-handlers-stop.html
- To prevent a second handler from running on the same object Calling
  
Capture/Bubble
Here we study what happens when an element is contained within Another
element.

nesting-basic.html
- Generally event will bubble from the innermost element to the
  outermost element.  All elements will be able to capture the event.

nesting-stop.html
- Calling stopPropagation on the event object will prevent bubbling 
  from occuring.

nesting-capture.html
- If we pass in "true" as the third parameter on our AddEventListener
  our listener will execute in the "capture" phase instead of the "bubble"
  phase.
- The capture phase occurs before the bubble phase.  It goes outside-in
  order rather than the bubble phases inside-out order.

nesting-capture-bubble.html
- We can run handlers on both the capture and bubble phases.

nesting-capture-bubble-stop.html
- stopPropagation will work during either phase.







