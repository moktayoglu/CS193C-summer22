function bodyKey() {
	alert("key pressed");
}

document.addEventListener("keypress",bodyKey);

