document.addEventListener("click",function() {alert("document clicked");});
document.getElementsByTagName("body")[0].addEventListener("click",function() {alert("body clicked");});