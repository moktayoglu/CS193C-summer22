// main.js

import {pi, power} from "./math.js";

console.log(pi);
console.log(power(2,10));
