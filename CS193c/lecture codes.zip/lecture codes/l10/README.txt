GLOBAL VARIABLES, WINDOWS, MODULES

global-content.js
- Demonstrates that global variables are actually properties
  of the window object in Browser-based JavaScript

Popup Examples

new-windows.html
example.html
- Shows how to open example.html file from new-windows.html
  as a popup window.

[Popup Communication]
main.html
popup.html
- By maintaining a reference to a window when we popup a window
  we can access that window's global variables.
- Demonstrates accessing a popups text field from original parent
  window.

[Advanced Popup Communication]
main.html
popup.html
- Same as above, but more complex interactions between the two
  windows.

Modules
NOTE THIS MUST BE PLACED ONLINE TO WORK.
Will work fine in Chrome, but Firefox requires the user to
perform security tweaks.
Only supported by ~85% of web browsers.

ecmascript6-modules.html
- Main HTML file for example.  Note use of "module" keyword
  in <script> tag.
main.js
- JavaScript file using a module.
math.js
- module providing math functions for those that want them.


FEATURE DETECTION
Feature detection is used to determine if a web browser supports
a particular feature.

feature-detection.html
- In this case we show the proper way to check for a feature.
- We check for the features location.href and window.location
  and we can see from JavaScript that these features exist.
- We look for the non-existent features location.snazzy
  and window.groovy and we can determine from JavaScript 
  that these features are not supported by our web browser.
- Finally we incorrectly just try to look for a global variable groovy
  we heard might be supported, this will lead to a crash if
  the variable is not there, so use window.groovy instead.


STRINGS
Strings in JavaScript are a bit different from C++ or Java in that
there is no char (Character) type, just a String type.  However,
Strings of length 1 often can be used similar to char.

Here are some simple examples showing String manipulation in
JavaScript

credit-verify.html
- This example checks a string to determine if it looks like
  a credit card number.
name.html
- This example converts from "first name last name" format to
  "last name, first name" format.
parse-price.html
- In this webpage we allow a user to enter a price using
  a format including "$" dollar signs, "," commas, and 
  "." decimal points and convert it to a JavaScript number

REGULAR EXPRESSIONS
JavaScript has extensive support for regular expressions.

parsing-class-names.html
- Here we use regular expresisons to parse a class name 
  such as CS193C to isolate the "CS", the "193", and the "C".


COOKIES
Cookies are used by websites to store information on a client's 
computer.  Information stored in a cookie during one visit
will be sent to the web server the next time the user visits
the website.
Cookie data can also be accessed and manipulated via JavaScript.

cookies.html
- This file shows some basic cookie functions such as setting
  and retrieving a value and removing a cookie name/value pair.

themes.index.html
choose-theme.html
jazzy.css, modern.css, standard.css, stanford.css
- In this example I show how we can allow the user to choose
  a different color theme for viewing our website.  That 
  theme choice is stored as a cookie and the next time
  the visit our webpage, we'll use their theme.

WEB STORAGE
If you only want to access data client-side, the newer 
Web Storage standard is easier to use than the traditional Cookies
approach.

basic-storage.html
- This example shows basic use of web storage to store
  key value pairs.


SVG (SCALABLE VECTOR GRAPHICS)
SVG can be used to create object-graphics (also known as VECTOR
graphics on a webpage).

svg-example.html
- Here's a simple example drawing some text and shapes on
  a webpage.

svg-programming.html
- We can modify SVG using the same methods (such as getElementById)
  or setAttribute) that we've already been using to modify our HTML.

svg-smil.html
- SMIL (Synchronized Multimedia Integration Langauage) can be used
  to animate SVG.

svg-smil.control.html
- SMIL even provides a means of controlling the animation, such
  as determining when to start or stop an animation.

CANVAS
The <canvas> element sets aside part of a webpage that can be
used as a drawing surface from JavaScript.  In contrast with
SVG, once drawn, an element such as a circle or square is
not remembered.  You can think of this as similar to the difference
between a bitmap painting program vs. an objecr-oriented drawing
program.

canvas-preset.html
- This example draws a preset drawing on a canvas.

canvas-interactive.html
- In this example we draw different shapes on the canvas
  based on user inputs.
- We also resize the canvas itself based on user inputs.


SYMBOLS
Historically we've used Strings when we want
to create a symbolic value (e.g., "Mercury", "Venus", "Mars").
JavaScript symbols (another ECMAScript 6 addition) allow
more efficient ways of creating symbolic values.
Symbols can be used to simulate the Enumerated types 
provided by other languages.

symbol.html
- basic example showing how symbols work.


DATA ATTRIBUTES
Data attributes allow us to add new attributes on to our HTML
tags.  You must precede the name of your attributes with "data-"
otherwise your code won't validate.
We access data attribute values from JavaScript using the
dataset property.

data-pizza.html
- Shows one potential use of data attributes, storing data
  on HTML elements and then retrieving it from JavaScript.


DRAG AND DROP (don't use for Map assignment)
The DOM now includes support for dragging and dropping elements
from one part of the webpage to another part, from one webpage
to another, or from the desktop to a webpage.

drag.html
- Simple example allowing dragging of photo onto the square.

drag2.html
- Allow dropping of several images onto a square.  
- To get this to work, we need to determine which of the
  images was dropped on the square.
- We set data on the dataTransfer property at dragstart.
- We retrieve that data on drop.

drag3.html
- There's lots of data on the dataTransfer property, in 
  addition to the data we put on it.  
- In this example we iterate through all the data types
  found on dataTransfer and print them out.
- We've commented out the functionality that displays the
  dragged element in the square in drag2.html.

drag4.html
- This is the same as drag3.html, except in this case we
  iterate through all the items instead of the data types.


GEOLOCATION
HTML5 added the ability to find a user's actual physical 
location.

goelocation.html
- Demonstrates how to use the HTML5 geolocation capability.
- Notice the use of a callback, as it may take some time
  to determine the user's location.

