FUNCTIONS

declaration.js
- There are many ways to define functions in JavaScript

function-constructor.js
- Functions are objects.  There are a variety of options when
  using the Function constructor.

hoisting-works.html
hoisting-works.js
- Using the traditional function definition we get hoisting,
  which allows us to reference a function earlier in the file 
  than its definition appears.

no-hoisting-fails.html
no-hoisting-fails.js
- This example doesn't work, because we don't use the 
  traditional method to define the function.  Only the
  traditional method supports hoisting.

parameters.js
- There are a variety of different things we can do with
  parameters in JavaScript programming.

pure-functions.js
- This file shows the difference between a function and a pure function.

first-class.js
- This file shows how JavaScript supports functions as first-class objects
  which can be passed as parameters, assigned to variables or object properties,
  or returned from other functions.

map-reduce-filter.js
- Shows use of the map, reduce, and filter methods available on Arrays.


CLOSURES
Closures are formed when we define one function inside of another.
This will have a number of different uses.

closure-mechanics.js
- Shows the basic mechanics of how closures work.

closure-privacy-example.js
- Closures are sometimes used to hide variables.  This example
  shows how this technique works.

closure-handler-example.js
- If we want to the same an event handler for different events, 
  but use different data in each case, we can use the same code
  and use closures to make each event handler different.

slides-closure.html
slides-no-closure.html
- We previously saw the slide show example, which depended 
  upon global variables to share data between different
  executions of our event handler.
- We can rewrite this using a closure to eliminate the
  global variables.


EVENT LOOP 
Event handlers all run on the same thread, so if your
event handler takes too long to run, your User Interface
will temporarily stop working.

bad-event-handler.html
- If click on "Bad Event Handler" the User Interface
  will stop working.

EVENT LOOP > WEB WORKERS
Web Workers allow us to create multiple threads.  PLACE THESE ONLINE
TO RUN THEM.

RUN IN CHROME ONLY.

prime.html
prime.js
- When we click on the button, go off and calculate prime numbers.  
  But don't do it on the event handler thread.
- Web worker constantly notifies main thread with new prime numbers

prime-adv.html
prime-adv.js
- Similar, but web worker only runs in response to requests.
