// JavaScript Functions are objects, and there is a Function object constructor
// Generally the other methods of defining or constructing Functions are preferred
// but for completeness, here's the Function constructor in action.

// Pass in a list of parameters.  The last parameter provided is the code to
// execute.  The parameters passed in before the last parameter are the arguments.
// Note all parameters are Strings

// Two parameters a and b for the function we are defining, and one line of code
var multiply = new Function("a", "b", "return a * b");

// No parameters for the function we are defining and one line of code
// Note use of single and double quotes to allow a string inside of another string
var printInfo = new Function("console.log('example')");

// Two parameters for the function we are defining and many lines of code
// Here I've taken advantage of the backquoted Template Literal, which allows
// me to create a string with carriage returns in the middle.
// That third parameter is a big long multi-line string.
var power = new Function("base", "exp",
`   var result = 1;
    for (var i = 0; i < exp; i++) {
        result = result * base;
    }
    return result;
`
);

// WARNING: Be very careful where you've taken the text you're using for the 
// final parameter.  Taking text and executing it as code makes you potentially
// vulnerable to an injection attack.