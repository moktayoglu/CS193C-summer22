// traditional function declaration hoists the function
// we can use it before the declaration appears

example();

function example() {
    console.log("example");
}

