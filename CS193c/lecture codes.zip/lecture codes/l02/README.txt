

STARTER FILES

starter-html.html
- A standard HTML5 starter file
 		
reset-meyer.css
reset.css
- Using a CSS reset can be helpful if you're trying to do a
  complex website design.  
- Without a CSS Reset, the default padding or margin of elements
  may cause your design to not size as expected.
- These are two alternative CSS versions from Eric Myer and 
  David Macfarland.
- Using them is optional, but you may find them useful.

FANCY CSS

Here are some fancy things you can do with CSS

calc-example.html 
- shows use of calc

variable-example.html
- shows use of CSS custom properties / aka CSS variables

import-example.html
example.css
- shows how to import a CSS file from with CSS

FANCY IMAGES

Some advanced things you can do with Images

sprites-example
- use CSS sprites to reduce the number of files to download

base64-example
- encode your images as Base64 to eliminate downloads entirely

GENERAL EXAMPLES

links-examples
- different examples of how to use CSS to create different 
  looks on a link 

caption.html
caption-adv.html
- I use these to show students how one might use classes
  and as an example of when a style sheet might make sense
  within a file instead of as an external file.
- caption-adv uses HTML5 new semantic tags, whereas 
  caption.html uses traditional tags only

blog.html
- shows how a blog might use classes

shakespeare.html
- use of Fragments in links