Here is a blank starter file to use for you HTML files.

Note that the starter-html.html file may display validation errors until you enter an actual title and fill in the body.

Also note that this file is a blank webpage.  If you open it in a text editor you will see the HTML tags needed to create a new webpage, but if you open it in a web browser you will see a blank webpage.