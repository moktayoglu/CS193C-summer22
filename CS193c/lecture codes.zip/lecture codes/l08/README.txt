SLIDE SHOW
This is the files for the previously presented Slide Show.  
It is most useful for showing use of preloading images.

slides.html
- This is just the images changing with no preload.
slides-w-preload.html
- As the name suggests, this is the same thing, but with images
  properly preloading

OBJECT BASICS
The files listed in this section have very extensive writeups
within each individual file.  Please read the actual files for 
details.

properties.html
- Different ways to access object properties

objects vs. arrays.html
- Objects allow numeric properties.
- Arrays have some additional features however.

array-like.html
- We will sometimes encounter objects which are
  referred to as "array-like".
- Here we see that many but not all Array features
  are available with these array-like objects.

functions and methods.html
  - We study how functions and methods are related
    to one another in JavaScript.

this.html
- In JavaScript we must explicitly use this when 
  referring to properties of an object

this-methods.html
- We must explictly use this when referring
  to a method as well.

this-methods2.html
- Same as above, but extra level of complexity to show
  access of global variables.

apply.html
- apply can be used to set this

apply vs. call.html
- call works very similarly, but the format is a bit
  different.

bind.html
- bind creates a new function based on an existing function
  and a specific object

bind-example.html
- bind can be used to pass information in to an event handler

OBJECT HIERARCHY

pair-no-constructor.html
- Create similar objects by duplicating code.

pair-no-prototype.html
- Use a constructor to share methods.

(aside) pair-no-prototype-optional-params.html
- We can't overload a constructor in JavaScript.
- Here's how we might try to get similar behavior

(aside) pair-without-new.html
- What happens if we don't use the keyword new
- You might want to set strict mode using "use strict";
- This will make this illegal instead of failing silently.

pair-w-prototype.html
- We can use a prototype to get similar behavior
  to pair-no-prototype.html.

simple-hierarchy.html
- We can use prototypes to form a hierarchy.

simple-shared-hierarchy.html
- Same as above, but with a slightly different hierarchy.

bigger-hierarchy.html
- A much larger hierarchy.

iteration.html
- Iterating through properties of an object.

CLASSES
Classes were added with EMCAScript 6 (ES2015).  While
you're welcome to use them, understanding prototype-based
objects as described previously is critical to programming
with JavaScript.
JavaScript existed for 20 years without classes, and the
DOM connection with the web browser is based on prototype-based
objects, not class-based objects (as is much of the JavaScript
language itself such as Arrays relationship to Objects).

classes.html
- A simple definition of a class.

classes-hierarchy.html
- An example showing a class hierarchy.

classes-private.html
- Currently JavaScript classes do not have a sense of public
  vs. private, so various hacks are used to simulate this.
- There is a proposal to support private by marking private
  entities with the # sign.  This might be added to ES2019,
  but it's not currently supported by web browsers.

