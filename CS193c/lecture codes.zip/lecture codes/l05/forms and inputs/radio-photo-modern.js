
function changePhoto() {
    document.getElementById("photo").src = 
            "images/" + document.getElementById("main").photoSelect.value;
        // As of 2018 this will not work in Microsoft Edge
}

document.getElementById("changePhotoButton").addEventListener("click",changePhoto);