JAVASCRIPT BASICS

convert.js
- a simple conversion function written in JavaScript

power.js
- a conversion function showing more JavaScript code than
  the convert.js

power-anonymous.js
- Functions are first class objects in JavaScript.  This
  does the same as power.js but using a different method for
  defining the function.
- We'll generally stick to the power.js format, as it's easier
  for less experienced programmers to understand.  But you'll
  see lots of code like this in professional code.

delivery.js
- Shows use of an array

location.js
- Shows use of object literals.

simple-execution.html
- we can simply stick a <script> tag into an HTML file
  and have it execute.

simple-button.html
- here we execute JavaScript using an onclick attribute.  
  This is the oldest form of JavaScript.

simple-button2.html
- this does the same thing as simple-button.html but it's 
  a more modern format.
- execute JavaScript to get a hold of the button and assign 
  a handler to it.

DOM TREE

displayTree.html
displayTree.js
- Webpage that displays the DOM tree in a dialog box.

BASIC DOM ACCESS
These examples show some basic accesses of the Document object.
They also show a number of different ways to attach a script
to a button.

These show access of the title property of the document and the
printing to the console (which is useful for debugging).

document-no-external.html
- In this example we set everything up in just the HTML file.
  Notice that the <script> tag setting up the buttons must
  occur after the <input> tag creating the button.

document-no-defer.html
document.js
- Same as with the last example, except the JavaScript is contained
  in an external JavaScript file.
- The <script> will get executed when loaded, so it must be
  placed below the <input> tag defining buttons.

document.html
document.js
- Here we use the defer attribute on the <script> tag to cause the
  JavaScript to execute after the rest of the HTML file has been
  parsed.
- This means we can put our script at the top of our file before
  the <input> buttons are defined.
- IMPORTANT: defer only works with external JavaScript files. 
  It cannot be used with code contained in the HTML file itself.
  This may also not work on older web browsers.

image-change.html
image-change.js
- We can access individual elements on the webpage using 
  document.getElementById
- In this case we use this to change the src of an image,
  which changes which image is displayed.

FORMS AND INPUTS

convert.html
convert.js
- Shows access of form elements by using getElementById
- Form element values will be treated as strings.  Depending
  on how you use them you may need to convert them using 
  parseInt or parseFloat

convert-traditional.html
convert-traditional.js
- We can access the Form itself and then use the Form to access
  individual elements in the Form.
- Form Elements act as properties of the Form object they are 
  contained within.

meals-via-id.html
meals-via-id.js
- For checkboxes we are interested in the checked property.
- In this case I access the checkboxes using getElementById

meals-via-form.html
meals-via-form.js
- Same as above, except using Form to access checkboxes

meals-through-array.html
meals-through-array.js
- The forms themselves are attached to the document as 
  an array.  The form elements are attached to the form as
  an array.
- Depending on what you're doing, you may find this array
  useful (primarily if you have a form with a whole bunch of
  identical elements within it, which are easier to access via
  array instead of giving them all their own individual names).

radio-photo-modern.html
radio-photo-modern.js
- We can't access <input type="radio" /> directly, we want
  to access the whole set of radio buttons.  So we access the
  form and then use the name of the radio button.
- On a modern web browser, we can then access value to get 
  the value of whatever radio element is selected.
- This will work on Edge now, but IE and older Edge web browsers
  will not support this.

radio-photo-modern.html
radio-photo-modern.js
- The more traditional method is to access radio button set
  just as above, but rather than accessing the value property
  instead there is an array of radio button objects.
- Iterate through those looking for whichever one is checked.

select-color.html
select-color.js
- We can access the value of a <select> tag.

select-date.html
select-date.js
- Sometimes we want to determine the index number selected
  in a <select> instead of the value.  In this case, we retrieve
  selectedIndex property.
  






