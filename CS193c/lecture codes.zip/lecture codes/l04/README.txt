Forms

ski-club.html
- Example showing most traditional form elements

form-css.html
- Demonstrates how to do layout of forms without tables.
- This is really only for purists, I think it makes sense to
  use tables for form layout.

html5-forms.html
- Shows use of form elements introduced with html5
- A few of these (mose notably color) may not work on even
  some relatively new web browsers

Image Maps

computer.html
- Shows basic use of Image Maps with rectangular areas
  only

museum.html
- More advanced examples with circles and polygons
- Note this is based on an old version of the Cantor Art
  Center map and is only a very small part of the overall
  art museum.  This museum is close by the Stanford CS building
  and I strongly recommend a visit.

IFrames (Inline Frames)

iframe.html
- Main file for our example.  This is the caption example
  from a few lectures ago, but it now has another webpage
  embedded within it.

cats.html
- This is the file that's been embedded into the iframe.html

youtube-embed.html
- Youtube videos are generally embedded using iframe elements.
  This is an example of how this works.

SVG (Scalable Vector Graphics)

svg-example.html
- SVG is an XML-based language allowing creation of object-based diagrams.
- This is an example of an HTML file with SVG embedded into it.

Audio/Video

audio.html
- example showing how to embed audio into a webpage

video.html
- example showing how to embed video into a webpage

youtube.html
- as noted above in the iframe section, youtube videos
  are generally embeded using an iframe, here's an example

JavaScript

convert.js
- a simple conversion function written in JavaScript

power.js
- a conversion function showing more JavaScript code than
  the convert.js

power-anonymous.js
- Functions are first class objects in JavaScript.  This
  does the same as power.js but using a different method for
  defining the function.
- We'll generally stick to the power.js format, as it's easier
  for less experienced programmers to understand.  But you'll
  see lots of code like this in professional code.

delivery.js
- Shows use of an array

location.js
- Shows use of object literals.

simple-execution.html
- we can simply stick a <script> tag into an HTML file
  and have it execute.

simple-button.html
- here we execute JavaScript using an onclick attribute.  
  This is the oldest form of JavaScript.

simple-button2.html
- this does the same thing as simple-button.html but it's 
  a more modern format.
- execute JavaScript to get a hold of the button and assign 
  a handler to it.
