Check the Handout "h04 Dynamic Content" for detailed
description of most of these examples.

ACCESSING ELEMENTS

using-id.html
- If you're trying to access a specific element, the best
  way to handle it is to give it an id and use getElementById.

using-tagname.html
- If you want to access a bunch of elements of the same type
  use getElementsByTagName.  
- Note this does not return a single element but rather an 
  array-like object containing multiple elements.

using-classname.html
- You can give elements class attributes and use that to
  access elements.  
- This also returns an array-like object containing multiple
  elements.

using-querySelector.html
- You can use a general CSS selector using querySelector.
- This only returns a the first element which matches 
  the CSS selector.
- Note that this is slower than the other more specific
  methods, so while you could use querySelector to selector
  something with an id, don't do it, use getElementById

using-querySelectorAll.html
- Using querySelectorAll works the same as querySelector
  except it returns an array-like object of all elements
  which match the CSS selector.

using-event-obj-DOM.html
- You can use the event object's target (or relatedTarget)
  to get access to the specific DOM element that caused
  an event to trigger.

using-documentElement.html
- You can actually access the entire HTML tree using the
  Document's documentElement property.  

ACCESSING AND CHANGING HTML ATTRIBUTES

casual-changing-image.html
- The HTML attributes on an element can generally be
  accessed as properties on their corresponding DOM
  objects.
- Here we change the src attribute and the title attribute
  of an image from JavaScript.

formal-changing-image.html
- There is a setAttribute method you can use instead of
  accessing via JavaScript properties.

casual-changing-class.html
- The formal method may be useful as occasionally you'll
  run into HTML attributes which don't work as properties
  in JavaScript.
- The HTML class attribute can't be accessed as a property
  named "class" because "class" is a reserved word in
  JavaScript.
- There will generally be a way to access it anyway, but
  you may have to do some looking to figure it out.
  In this case the property is renamed as className.

formal-changing-class.html
- Here we use setAttribute and we can use class rather than
  className, because we pass in the attribute name as access
  string and therefore there's no problem that class is access
  reserved word.

CLASSLIST
A relatively new addition is a property called classList
which can be used to add or remove classes from an element.
It can also be used to toggle classes.

classList.html
- Demonstration of use of classList

CHANGING AND ACCESSING STYLE

changing-style-informal.html
- Informal changing of a style using a property of the
  style object.

changing-style-dom.html
- The official W3C specification provides a setProperty
  method.

accessing-style-limited.html
- If a style is set using an HTML element's style attribute,
  it can be accessed using the same method we used to change it.

accessing-style-limited-trouble.html
- Here the style is set using the <style> tag.  If we do 
  this we can't acess using the simple method. 
- This example doesn't work.

accessing-style-dom.html
- The official W3C DOM method for getting a style value 
  requires using the defaultView.

accessing-style-ie.html
- This example shows how you would need to access a style
  if you want to support Internet Explorer.

GETBOUNDINGRECT
getBoundingRect can be used to get information on the location
of a rectangle.  It is _not_ the same as accessing the top and left
properties of an element placed using absolute or relative 
placement.

getBoundingClientRect-no-position.html
- getBoundingClientRect works regardless of whether the
  element was placed using default (static) placement or
  absolute, relative, or fixed placement

getBoundingClientRect-absolute.html
- If the entire webpage fits in the web browser window,
  getBoundingClientRect appears to give the same results
  as computed top and left style.

getBoundingClientRect-absolute-scrolling.html
- However, if any scrolling has occurred we see that
  getBoundingClientRect is measured from the top-left
  corner of the window, whereas computed style top-left
  is relative to the top-left corner of the webpage, event
  if that corner has scrolled off the top of the window.

getBoundingClientRect-absolute-nested.html
- Computed Style also takes nesting into account and instead
  relative to the parent absolute or relatively placed 
  element.
- getBoundingClientRect ignores any nesting and is always
  relative to the top-left of the window.

getBoundingClientRect-relative.html
- getBoundingClientRect gives completely different results
  compared to computedStyle on a relatively placed element.

MODIFYING DOM TREE
There are two ways to modify the elements in the tree.
We can use the innerHTML introduced by Microsoft Internet
Explorer or we can use the official W3C DOM model.

In this case the Microsoft innerHTML is much easier to use
and has become widely supported.  So for most purposes, this
is probably the best way to go.

Check the "h04 Dynamic Content" handout for a detailed 
description of how the W3C DOM examples work.

changing-element-innerHTML-basic.html
- In this example we change the innerHTML of the h1 element.

changing-element-innerHTML.html
- This is similar but allows the user to enter the new innerHTML
  in a text field.  
- Try entering text with and without HTML tags in it.

changing-element-innerText.html
- This example shows the difference between innerHTML and 
  innerText.
- Try entering some text with a tag here and contrast that
  with what happens with the same text when entered on the
  changing-element-innerHTML.html webpage.

changing-element-innerHTML-IE-trouble.html
- Some elements can't have their innerHTML changed in
  most versions of IE and some versions of Edge.
- If you run this example in those web browsers it 
  won't work.

changing-element-DOM-basic.html
- Replacing text using the official W3C DOM method.

changing-element-DOM-trouble.html
- Unlike innerHTML, the DOM method doesn't parse for tags.
- This example doesn't work the way we want it to.

changing-element-DOM-adv.html
- Here's the correct way to do the last example using
  the W3C method.   Definitely messier than innerHTML.

changing-element-DOM-nodeValue.html
- It's possible in some cases to go in and modify nodeValues
  rather than creating new nodes.

[if you're wondering, changing the nodeName doesn't seem 
 to do anything]

FULL EXAMPLES

dragging-position.html
- Allowing the user to drag an element around by changing
  its position.
- Note that I've placed style directly on the element, which
  allows me to avoid using defaultView and getComputedStyle.
  This simplifies the code.

dragging-transform.html
- This is the same thing as above, but uses CSS transform.
- Some articles suggest this will give a smoother result,
  but it does seem like more work.

scripted-movement.html
- In this example we move an element across the screen by
  combining changing its position and using setInterval

track-typing.html
- In this example I track what the user is typing and reset
  it if the user pauses for 0.5 a second.
- You might use code like this to display autofill choices
  tracking what the user types, but allowing them to setAttribute
  over if they pause briefly.

FULL EXAMPLE / SCROLLING MARQUEE

scroll-html-only.html
- This is our original message with no scrolling.
- Note setting size on element with overflow: hidden to
  eliminate any overflow.

scroll-basic.html
- Here I've added an inner div which moves up and down.
- For this example it scrolls up and disappears.

scroll-repeating.html
- For the final iteration of the problem I reset the
  position after it scrolls of the top to start down
  at the bottom.

FULL EXAMPLE / TOOLTIPS

stanford-original.html
- Text with no tooltips and no JavaScript

stanford.html
- Tooltips added, they are initially hidden but are measured
  visible as the user moves the mouse on top of various words.
- You could also use display: none rather than visibility: hidden.

FULL EXAMPLE / TREE MENU

tree-menu.html
- A collapsing tree menu created by making elements either
  display: none or display: block.


