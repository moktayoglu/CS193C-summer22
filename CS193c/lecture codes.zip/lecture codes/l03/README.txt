FLOAT-BASED LAYOUT
Check the handout for full listings of all class examples.
I've provided several of the completed examples if you want to
play with them

three-columns.html
- A three column layout

three-to-two.html
- Three columns above, two columns below

complex.html
- A more complex layout

FLEX-BASED LAYOUT

flex-basic-column.html
- Showing how to create basic columns with flex

flex-two-panel.html
- Similar to the three column to two column example from
  float but with flexbox

flex-complex.html
- Same complex example but with flex.

GRID-BASED LAYOUT

See Grid Handout for description of the files numbered 01 to 10.

grid-complex.html
- Here's the complex example we've seen previously using grid

grid-complex-shorthand.html
- Same as above using a different method to specify start and end
  rows and columns

grid-complex-shorthand-span.html
- Same as above using a span method to specify start and end
  rows and columns


RESPONSIVE DESIGN
Some of these require a tablet to show.  For those examples, 
I've provided screenshots.

responsive.html
- Adds or removes sidebar (removes by setting display to none)
  based on width of screen.

side-vs-top.html
- Moves a sidebar from the side to the top based on the width
  of the screen.

orientation.html
- Similar to responsive, but changes layout based on orientation.

orientation-grid.html
- Also demonstrates change based on orientation, but uses
  grid layout

touch.html
- Demonstrates changing size of buttons based on whether the user has
  a fine pointer (e.g., a mouse or perhaps a pencil) vs. a coarse
  pointer (e.g., a finger)

ADVANCED CSS
Here are some advanced techniques that may occasionally be useful.

relative-used-with-absolute.html
- Contrary to its name, CSS absolute positioning occurs 
  relative to the containing element if the containing element its
  absolute, relative, or fixed.
- If we aren't sure where an element will end up, and we want to 
  place an element relative to that, but we don't want to leave space
  for it (as is done with straight relative placement), we can combine
  relative with absolute placement.
- Here the inner div "b" is placed at a location determined by the
  regular placement of the inner div "a".

sticky-example.html
- CSS positioning has a new sticky value that can be used to sticky
  an element at a specific position once it has scrolled up or down to
  a given position.
- This is not yet fully supported by all web browsers in use.

transform.html
transform2.html
- CSS Transform can be used to rotate, scale, and otherwise manipulate
  elements on the webpage

animate.html
- We can animate changes from one CSS state to another by specifying
  a series of key frames.
- We can control the speed of the animation and delay the start of 
  the animation.
- If you want to trigger whether the animation occurs at all though, 
  you should either use CSS Transition (see below) or use JavaScript.

transition.html
- CSS Transition can be used in conjunction with pseudo-classes (or
  with JavaScript) to show a "gradual" change of an element from one
  set of CSS properties to another.
