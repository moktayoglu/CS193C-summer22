base64.html
-- for real efficiency, we can store our images directly within the HTML file as bit strings

iframe and click-jacking
-- iframes are used by malicious actors for clickjacking

   iframe.html
      -- shows a basic use of an iframe with cat.html inside of iframe.html
   iframe-position.html 
      -- we can move the iframe on top of other elements using position: absolute
   iframe-position-transparent.html
      -- the clickjacker makes the iframe completely transparent, although in my
         example I've left some opacity

properties

  property-flags.html
  -- the enumerable, writeable, and configurable flags can modify an objects
     behavior

  getters-and-setters.html
  -- setting and getting properties can actually call functions